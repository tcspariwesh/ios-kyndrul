// Numeric Type Conversion
